package a5;

public class ScopeStackException extends Exception
{
	private static final long serialVersionUID = 1L;

	public ScopeStackException(String msg)
	{
		super(msg);
	}
}

